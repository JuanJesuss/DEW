<?php
function decimalAbinario($num1){
    $binario= sprintf("%b",$num1);
    echo "Numero binario: <input type=text value=$binario>";
}
?>