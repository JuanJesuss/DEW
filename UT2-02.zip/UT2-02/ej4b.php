<!DOCTYPE HTML>
<HTML>

<HEAD>
<TITLE>EJ4B – Tabla de multiplicar del 9</TITLE>
<META charset="utf-8"/>
</HEAD>

<BODY>

<?php

$num=9;

for($i=1; $i<=10; $i++)
    echo $num."*$i= ".$num*$i."<br/>";

?>

</body>

</html>
