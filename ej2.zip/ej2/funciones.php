<?php
function sumarNumeros($num1,$num2){
    echo "Resultado operación: ",$num1," + ",$num2," = ",$num1+$num2;
}


function restarNumeros($num1,$num2){
    echo "Resultado operación: ",$num1," - ",$num2," = ",$num1-$num2;
}   


function productoNumeros($num1,$num2){
    echo "Resultado operación: ",$num1," * ",$num2," = ",$num1*$num2;
}


function divisionNumeros($num1,$num2){
    echo "Resultado operación: ",$num1," / ",$num2," = ",$num1/$num2;
}
?>